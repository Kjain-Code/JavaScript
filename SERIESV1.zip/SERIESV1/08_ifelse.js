if (112>13) {
    console.log("True")
}

if (56) {  // concept of truthy and falsy 
    console.log("True")
}
else{
    console.log("False")
}


if(loggenIn && admin){
    console.log("")
}
else if (loggenIn || admin){

}
else{

}


// nothing advance just simple conditional statements 