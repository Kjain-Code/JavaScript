// start 
// while (end) {
//     code
//     change
// }


let i = 1
while(i<+30){
    console.log(i)
    i++
}

// start
// do{
// code 
// change
// }
// while(end)
// print at least one time 

let j = 12
do{
    console.log(j)
    j++
}
while(j<10)  // consition false hone ke baad bhi ye ek baar chala 


// break stops the loop completely.
// continue skips the current iteration and continues with the next one.