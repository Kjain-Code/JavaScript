console.log("Kritika")

// you can run the javascript code on console by attaching the file to an HTML document or using a JavaScript environment like Node.js.
// now in this new folder I have installed the node js and now I want to run this file in the terminal
// to run this file in the terminal, I will use the command `node First.js`

