switch (key) {
    case value:
        
        break;

    default:
        break;
}


// break is used to make the code exit once an condition satisfy 