(function (){
    const password = "Secret Password";
    console.log(password)
})()


// console.log(password)
// this will give error aap usko function ke andar hi access kar sakte ho bhr nhi 
